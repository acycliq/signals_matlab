function id = open(sampleRate, nChannels, devIdx, suggestedLatency)
%audstream.open Opens a new audio stream
%   Detailed explanation goes here
%
%   id = audstream.open(sampleRate, [nChannels], [devIdx], [suggestedLatency])
end