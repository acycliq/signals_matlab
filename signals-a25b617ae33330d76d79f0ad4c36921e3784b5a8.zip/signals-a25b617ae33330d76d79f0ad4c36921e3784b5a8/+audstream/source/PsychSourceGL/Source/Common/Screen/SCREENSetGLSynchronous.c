/*
  SCREENSetGLSynchonous.cpp		
  
  AUTHORS:
  Allen.Ingling@nyu.edu		awi 
  
  PLATFORMS:	All
    
  This file is dead and pointless.

  HISTORY:
  12/18/01  awi		Created.  Copied the Synopsis string from old version of psychtoolbox.  
 
  TO DO:
  

*/
