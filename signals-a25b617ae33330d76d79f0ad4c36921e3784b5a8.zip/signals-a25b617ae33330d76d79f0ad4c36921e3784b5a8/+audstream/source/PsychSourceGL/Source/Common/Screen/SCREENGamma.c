/*
  Psychtoolbox3/Source/Common/SCREENGamma.c		

  THIS FUNCTION IS DEAD - NEVER USED, WON'T BE EVER USED.
*/
